import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class TaskService {
 //creates a static instance of ArrayList of Task
 public static List<Task> tasks = new ArrayList<>();
 public static void main(String[] args) {
 //create an instance of TaskService
 TaskService service = new TaskService();
 //creates the tasks and adds them to list, uses new task service
 service.addTask(new Task("1111", "Juicing", "Juicing fresh fruit"));
 service.addTask(new Task("2222", "Gaming", "Playing Xbox Series X"));
 service.addTask(new Task("3333", "Weightlifting", "Doing bench presses"));

 //displays the tasks
 for (Task obj : tasks) {
 System.out.println(obj);
 }

 //create an existing task ID
 service.addTask(new Task("5555", "Dancing", "Attending dance recital"));
 System.out.println("Delete Task ID #2222");
 service.deleteTask("2222");
 System.out.println("Update Task ID #3333");
 service.update(new Task("3333", "Swimming", "Going to the beach"));
 //display all added and updated Task object
 for (Task obj : tasks) {
 System.out.println(obj);
 }
 }
 public boolean addTask(Task task) {
	 //if task ID is not found, this will return negative values
	 int index = getIndex(task);
	 //validate id if doesn't exist, name & description
	 if (index < 0 && validateID(task.getTaskID()) &&
	validateName(task.getTaskName()) && validateDescription(task.getTaskDescription()))
	{
	 tasks.add(task);
	 return true;
	 }

	 return false;
	 }
//delete task id if it already exists
public boolean deleteTask(String id) {
//create new instance of Task object and pass the String ID in the constructor, set name and description as empty or null
//if ID found, return int value as list
int index = getIndex(new Task(id, "", ""));

//check if index is greater than or equal to 0
if (index >= 0) {
tasks.remove(index);
return true;
}
return false;
}
//updates task if task ID matches existing
public boolean update(Task task) {
for (Task obj : tasks) {
if (obj.equals(task) && validateName(task.getTaskName()) &&
validateDescription(task.getTaskDescription())) {
obj.setName(task.getTaskName());
obj.setDescription(task.getTaskDescription());
return true;
}
}
return false;
}
public int getIndex(Task task) {
	 int index = Collections.binarySearch(tasks, task, Task.compareById);
	 return index;
	 }
	 //validates id based on not null and length
	 public boolean validateID(String id) {
	 if (id != null && id.length() <= 10)
	 return true;
	 return false;
	 }
	 //validates name parameter based on not null and length
	 public boolean validateName(String name) {
	 if (name != null && name.length() <= 20)
	 return true;
	 return false;
	 }
	 //validates task description based on not null and length
	 public boolean validateDescription(String description) {
	 if (description != null && description.length() <= 50)
	 return true;
	 return false;
	 }
}