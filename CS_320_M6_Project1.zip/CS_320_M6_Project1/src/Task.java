import java.util.Comparator;
public class Task {
 //private access modifier for encapsulation
 private String taskId;
 private String taskName;
 private String taskDescription;
 //public constructor of Task object accepting 3 String parameters
 public Task(String id, String name, String description) {
 this.taskId = id;
 this.taskName = name;
 this.taskDescription = description;
 }
 //public getters to get the value of private variable
 public String getTaskID() {
 return taskId;
 }
 public String getTaskDescription() {
 return taskDescription;
 }
 public String getTaskName() {
 return taskName;
 }
 //public setters to set the value of private variable
 public void setId(String taskId) {
 if (taskId == null || taskId.length() > 10) {
 throw new IllegalArgumentException(
 "Error: The task ID was null or longer than 10 characters");
 } else {
 this.taskId = taskId;
 }
 }
 public void setName(String taskName) {
 if (taskName == null || taskName.length() > 20) {
 throw new IllegalArgumentException(
 "Task name is too long or null. Ensure it is no more than 20 characters and not null.");
 } else {
 this.taskName = taskName;
 }
 }
 public void setDescription(String taskDescription) {
 if (taskDescription == null || taskDescription.length() > 50) {
 throw new IllegalArgumentException(
 "Task description is too long or null. Ensure it is no more than 50 characters and not null.");
 } else {
 this.taskDescription = taskDescription;
 }
 }

 @Override
 public boolean equals(Object obj) {
 if (this == obj)
 return true;
 if (obj == null)
 return false;
 if (this.getClass() != obj.getClass())
 return false;
 Task t = (Task) obj;
 return getTaskID().equals(t.getTaskID());
 }
 
 @Override
 public String toString() {
 return "Task ID: " + getTaskID() + "\nName: " + getTaskName() +
"\nDescription: " + getTaskDescription() + "\n";
 }
}
