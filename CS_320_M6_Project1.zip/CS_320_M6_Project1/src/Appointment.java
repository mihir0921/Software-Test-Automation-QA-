import java.util.Date;
public class Appointment {
 // required variables
 private byte APPOINTMENT_ID_LENGTH;
 private byte APPOINTMENT_DESCRIPTION_LENGTH;
 private String INITIALIZER;
 public String apptId;
 public Date apptDate;
 public String apptDescription;
 {
 APPOINTMENT_ID_LENGTH = 10;
 APPOINTMENT_DESCRIPTION_LENGTH = 50;
 INITIALIZER = "INITIAL";
 }
 //all constructors listed below
 Appointment() {
 Date today = new Date();
 apptId = INITIALIZER;
 apptDate = today;
 apptDescription = INITIALIZER;
 }
 Appointment(String id) {
 Date today = new Date();
 updateAppointmentID(id);
 apptDate = today;
 apptDescription = INITIALIZER;
 }
 Appointment(String id, Date date) {
 updateAppointmentID(id);
 updateDate(date);
 apptDescription = INITIALIZER;
 }
 Appointment(String id, Date date, String description) {
 updateAppointmentID(id);
 updateDate(date);
 updateDescription(description);
 }
 //these are the three getters
 public String getApptDescription() {
 return apptDescription;
 }
 public String getApptId() {
 return apptId;
 }
 public Date getApptDate() {
 return apptDate;
 }
 //this is the update Appointment ID function
 public void updateAppointmentID(String id) {
	 //this catches if the appt ID is longer than 10 or null
	 if (id == null) {
	 throw new IllegalArgumentException("Appointment ID cannot be null.");
	 }
	 //appt object must be 10 or less
	 else if (id.length() > APPOINTMENT_ID_LENGTH) {
	 throw new IllegalArgumentException("Appointment ID cannot exceed " +
	 APPOINTMENT_ID_LENGTH +
	 " characters.");
	 }
	 else {
	 this.apptId = id;
	 }
	 }
	 //update date function
	 public void updateDate(Date date) {
	 //catches if Appointment date is null
	 if (date == null) {
	 throw new IllegalArgumentException("Appointment date cannot be null.");
	 }
	 //this checks if the date is in the past
	 else if (date.before(new Date())) {
	 throw new IllegalArgumentException("Cannot make appointment in the past.");
	 }
	 else {
	 this.apptDate = date;
	 }
	 }
	 //this is the update description function
	 public void updateDescription(String description) {
	 //catches if the The description field is null
	 if (description == null) {
	 throw new IllegalArgumentException(
	 "Appointment description cannot be null.");
	 }
	 // The appointment object must be 50 or lss caharacters
	 else if (description.length() > APPOINTMENT_DESCRIPTION_LENGTH) {
	 throw new IllegalArgumentException("Appointment description cannot exceed " + APPOINTMENT_DESCRIPTION_LENGTH + " characters.");
	 }
	 else {
	 this.apptDescription = description;
	 }
	 }
	}