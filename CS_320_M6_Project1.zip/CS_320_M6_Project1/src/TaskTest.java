import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
class TaskTest {
 private String id;
 private String name;
 private String description;
 private String tooLargeId;
 private String tooLargeName;
 private String tooLargeDescription;
 @BeforeEach
 void setUp() {
 id = "12345667";
 name = "mike";
 description = "None";
 tooLargeId = "123456789090976543";
 tooLargeName = "iunfer nkjnfevee kfejfengemvnkdedv vedv";
 tooLargeDescription =
 "This description is far too long to be attached to a task, descrptions cannot be more than 50 characters or null";
 }

 //tests are the same for all 3, so will just comment the first one
 @Test
 void tooLargeId() {
//creates new task with proper variables
 Task task = new Task(id, name, description);
 //tests that null value will throw illegal argument
 assertThrows(IllegalArgumentException.class,
 () -> task.setId(null));
 //tests that too large of a value will throw illegal argument
 assertThrows(IllegalArgumentException.class,
 () -> task.setId(tooLargeId));
 //tests that expected value is result of proper input
 assertEquals(id, task.getTaskID());
 }

 @Test
 void tooLargeName() {
 Task task = new Task(id, name, description);
 assertThrows(IllegalArgumentException.class,
 () -> task.setName(null));
 assertThrows(IllegalArgumentException.class,
 () -> task.setName(tooLargeName));
 assertEquals(name, task.getTaskName());
 }

 @Test
 void tooLargeDescription() {
 Task task = new Task(id, name, description);
 assertThrows(IllegalArgumentException.class,
 () -> task.setDescription(null));
 assertThrows(IllegalArgumentException.class,
 () -> task.setDescription(tooLargeDescription));
 assertEquals(description, task.getTaskDescription());
}
}