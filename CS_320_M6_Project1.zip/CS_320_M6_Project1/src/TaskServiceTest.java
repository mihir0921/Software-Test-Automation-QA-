import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
public class TaskServiceTest {
@Test
public void testAdd() {
TaskService ts = new TaskService();
//sets task list to test below
Task t1 = new Task ("1111", "Juicing", "Juicing fresh fruit");
Task t2 = new Task ("2222", "Gaming", "Playing Xbox Series X");
Task t3 = new Task ("3333", "Weightlifting", "Doing bench presses");
//shows the test work when adding tasks to list
assertEquals(true, ts.addTask(t1));
assertEquals(true, ts.addTask(t2));
assertEquals(true, ts.addTask(t3));
//shows the test does not work when trying to add existing task to list
assertEquals(false, ts.addTask(t3));
}
@Test
public void testDelete() {
TaskService ts = new TaskService();
//sets task list to test below
Task t1 = new Task ("1111", "Juicing", "Juicing fresh fruit");
Task t2 = new Task ("2222", "Gaming", "Playing Xbox Series X");
Task t3 = new Task ("3333", "Weightlifting", "Doing bench presses");
ts.addTask(t1);
ts.addTask(t2);
ts.addTask(t3);
//shows the test work when trying to remove task given taskID
assertEquals(true, ts.deleteTask("1111"));
assertEquals(true, ts.deleteTask("2222"));
//shows the test does not work when trying to remove task given
incorrect taskID
assertEquals(false, ts.deleteTask("4444"));
}
@Test
public void testUpdate() {
TaskService ts = new TaskService();
//sets task list to test below
Task t1 = new Task ("1111", "Juicing", "Juicing fresh fruit");
Task t2 = new Task ("2222", "Gaming", "Playing Xbox Series X");
Task t3 = new Task ("3333", "Weightlifting", "Doing bench presses");
ts.addTask(t1);
ts.addTask(t2);
ts.addTask(t3);
//shows the test work when trying to update task given taskID
assertEquals(true, ts.update(new Task("2222", "Suing", "Going to court")));
assertEquals(true, ts.update(new Task("3333", "Swimming", "Going to the beach")));
//shows the test does not work when trying to update task given incorrect taskID
assertEquals(false, ts.update(new Task("4444", "Failing", "Not going to update due to incorrect taskID")));
}
}
