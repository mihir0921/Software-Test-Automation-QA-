import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
class AppointmentServiceTest {
 private String id;
 private String description;
 private String tooBigDescription;
 private Date date;
 private Date beforeDate;
 @SuppressWarnings("deprecation")
 @BeforeEach
 void setUp() {
//sets appropriate variables within constraints
 id = "0123456789";
 description = "This is the description of the appointment";
 date = new Date(2025, Calendar.FEBRUARY, 12);
 //ses variables outside of constraints
 tooBigDescription = "This description is far too long given the constraints we put on that size of the description";
 beforeDate = new Date(0);
 }
 @Test
 void testNewAppointment() {
 AppointmentService service = new AppointmentService();
 service.newAppointment();
 //ensures expected returned value is not null given input
 assertNotNull(service.getAppointmentList().get(0).getApptId());
 assertNotNull(service.getAppointmentList().get(0).getApptDate());
 assertNotNull(service.getAppointmentList().get(0).getApptDescription());
 service.newAppointment(date);
 //ensures expected returned value is not null given input
 assertNotNull(service.getAppointmentList().get(1).getApptId());
 //ensures expected value is returned given input
 assertEquals(date,
 service.getAppointmentList().get(1).getApptDate());
 assertNotNull(service.getAppointmentList().get(1).getApptDescription());
 service.newAppointment(date, description);
 assertNotNull(service.getAppointmentList().get(2).getApptId());
 //ensures expected value is returned given input

 assertEquals(date,
 service.getAppointmentList().get(2).getApptDate());
 assertEquals(description,
 service.getAppointmentList().get(2).getApptDescription());
 //ensures illegal arguments exception is thrown given null annd too many characters input
 assertThrows(IllegalArgumentException.class,
 () -> service.newAppointment(beforeDate));
 assertThrows(IllegalArgumentException.class,
		 () -> service.newAppointment(date, tooBigDescription));
 }
 @Test
 void deleteAppointment() throws Exception {
 AppointmentService service = new AppointmentService();
 service.newAppointment();
 service.newAppointment();
 service.newAppointment();
 //creates test ID to use below
 String testId = service.getAppointmentList().get(0).getApptId();
 assertThrows(Exception.class, () -> service.deleteAppointment(id));
 //deletes testId
 service.deleteAppointment(testId);
 //ensures exception is thrown and that the test id was properly deleted
 assertThrows(Exception.class, () -> service.deleteAppointment(testId));
 assertNotEquals(testId,
 service.getAppointmentList().get(0).getApptId());
 }
}		 