import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
class AppointmentTest {
 public String id;
 public String description;
 public String tooBigId;
 public String tooBigDescription;
 public Date date;
 public Date beforeDate;
 @SuppressWarnings("deprecation")
 @BeforeEach
 void setUp() {
 //these variables fit the constraints we set
 id = "1234567890";
 description = "This is the description of the appointment";
 date = new Date(2025, Calendar.NOVEMBER, 17);
 //these variables are are outside the parameters we set
 tooBigId = "012345678901234567890";
 tooBigDescription = "We need a description that is too long for the description parameters, and this one should accomplish that.";
 beforeDate = new Date(0);
 }

 @Test
 void testGetAppointmentID() {
 Appointment appointment = new Appointment(id);
 //ensures that the returned value is not null
 assertNotNull(appointment.getApptId());
 //ensures that the correct expeted value is returned
 assertEquals(appointment.getApptId().length(), 10);
 assertEquals(id, appointment.getApptId());
 }
 @Test
 void testUpdateAppointmentID() {
 Appointment appointment = new Appointment();
 //expects illegal arguments to be thrown due to null values and too many characters
 assertThrows(IllegalArgumentException.class,
 () -> appointment.updateAppointmentID(null));
 assertThrows(IllegalArgumentException.class,
 () -> appointment.updateAppointmentID(tooBigId));
 appointment.updateAppointmentID(id);
 //ensures that the correct expected value is returned
 assertEquals(id, appointment.getApptId());
 }

 @Test
 void testGetAppointmentDate() {
 Appointment appointment = new Appointment(id, date);
 //ensures that the value returned is not null give input
 assertNotNull(appointment.getApptDate());
 //ensures the expected value is returned given input
 assertEquals(date, appointment.getApptDate());
 }
 @Test
 void testUpdateDate() {
 Appointment appointment = new Appointment();
 //expects illegal argument to be thrown due to null value and too manycharacters
 assertThrows(IllegalArgumentException.class, () ->
appointment.updateDate(null));
 assertThrows(IllegalArgumentException.class, () ->
appointment.updateDate(beforeDate));
 appointment.updateDate(date);
 //ensures the expected value is returned
 assertEquals(date, appointment.getApptDate());
 }

 @Test
 void testGetDescription() {
 Appointment appointment = new Appointment(id, date, description);
 //ensures the returned value is not null given input
 assertNotNull(appointment.getApptDescription());
 //esnures the expected values are returned given appropriate inputs
 assertTrue(appointment.getApptDescription().length() <= 50);
 assertEquals(description, appointment.getApptDescription());
 }
 @Test
 void testUpdateDescription() {
 Appointment appointment = new Appointment();
 //expects illegal argument exception to be thrown due to null and too many characters
 assertThrows(IllegalArgumentException.class, () ->
appointment.updateDescription(null));
 assertThrows(IllegalArgumentException.class, () ->
appointment.updateDescription(tooBigDescription));
 appointment.updateDescription(description);
 //ensures that expected value is returned due to input
 assertEquals(description, appointment.getApptDescription());
 }
}