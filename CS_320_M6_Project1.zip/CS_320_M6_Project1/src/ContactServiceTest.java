import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
public class ContactServiceTest {
@Test
public void testAdd() {
ContactService cs = new ContactService();
//sets contact list to test below
Contact c1 = new Contact ("99001", "mike", "andy", "1234 Santa Dr", "2148907654");
Contact c2 = new Contact ("98002", "jacky", "joe", "5678 Fe Dr", "2142354678");
Contact c3 = new Contact ("97003", "bunty", "monty", "91011 Royal St", "2140987234");
//shows the test work when adding contacts to list
assertEquals(true, cs.newContact(c1));
assertEquals(true, cs.newContact(c2));
assertEquals(true, cs.newContact(c3));
//shows the test does not work when trying to add existing contact to
list
assertEquals(false, cs.newContact(c3));
}
@Test
public void testDelete() {
ContactService cs = new ContactService();
//sets contact list to test below and adds to list
Contact c1 = new Contact ("1111", "mike", "andy", "1234 Santa Dr", "2148907654");
Contact c2 = new Contact ("2222", "jacky", "joe", "5678 Fe Dr", "2142354678");
Contact c3 = new Contact ("3333", "bunty", "monty", "91011 Royal St", "2140987234");
assertEquals(true, cs.newContact(c1));
assertEquals(true, cs.newContact(c2));
assertEquals(true, cs.newContact(c3));
//shows the test work when trying to remove contact given contactID
assertEquals(true, cs.removeContact("1111"));
assertEquals(true, cs.removeContact("2222"));
//shows the test does not work when trying to remove contact given incorrect contactID
assertEquals(false, cs.removeContact("4444"));
}
@Test
public void testUpdate() {
ContactService cs = new ContactService();
//sets contact list to test below
Contact c1 = new Contact ("88001", "mike", "andy", "1234 Santa Dr", "2148907654");
Contact c2 = new Contact ("88002",  "jacky", "joe", "5678 Fe Dr", "2142354678");
Contact c3 = new Contact ("3333", "bunty", "monty", "91011 Royal St", "2140987234");
assertEquals(true, cs.newContact(c1));
assertEquals(true, cs.newContact(c2));
assertEquals(true, cs.newContact(c3));
//shows the test work when trying to update existing contact
assertEquals(true, cs.updateContact("22001", "John", "Lennon", "1 West 72nd St", "7224506709"));
assertEquals(true, cs.updateContact("33002", "Ringo", "Starr", "225 Record Ave", "7228889999"));
//shows that the test works when you try to update with an incorrect contactID
assertEquals(false, cs.updateContact("55004", "Ringo", "Starr", "225 Record Ave", "7223456789"));
}
}
