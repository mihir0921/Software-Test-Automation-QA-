import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
public class AppointmentService {
//array list to store appointments
 final private List<Appointment> appointmentList = new ArrayList<>();
 //his creates a random ID
 private String newUniqueId() {
 return UUID.randomUUID().toString().substring(
 0, Math.min(toString().length(), 10));
 }
 //these are the constructors
 public void newAppointment() {
 Appointment appt = new Appointment(newUniqueId());
 appointmentList.add(appt);
 }
 public void newAppointment(Date date) {
 Appointment appt = new Appointment(newUniqueId(), date);
 appointmentList.add(appt);
 }
 public void newAppointment(Date date, String description) {
 Appointment appt = new Appointment(newUniqueId(), date, description);
 appointmentList.add(appt);
 }
 //deletes appt given the ID
 public void deleteAppointment(String id) throws Exception {
 appointmentList.remove(searchForAppointment(id));
 }
 protected List<Appointment> getAppointmentList() {
 return appointmentList;
 }
 //this function searches list of appointments to ensure the appt exists
 private Appointment searchForAppointment(String id) throws Exception {
 int index = 0;
 //while loop goes through the size of list
 while (index < appointmentList.size()) {
 if (id.equals(appointmentList.get(index).getApptId())) {
 //returns if it finds appt in list given the ID
 return appointmentList.get(index);
 }
 index++;
 }
 //returns exception if no appt is found
 throw new Exception("Unfortunately the appointment does not exist!");
 }
}