import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class ContactTest {
//declaring variables
 private String contactIdTest;
 private String firstNameTest;
 private String lastNameTest;
 private String phoneNumberTest;
 private String numberAddressTest;
 private String tooBigContactId;
 private String tooBigFirstName;
 private String tooBigLastName;
 private String tooBigPhoneNumber;
 private String tooSmallPhoneNumber;
 private String tooBigNumberAddress;
 @BeforeEach
 void setUp() {
//assigning values to variables
 contactIdTest = "123456789";
 firstNameTest = "mike";
 lastNameTest = "pat";
 phoneNumberTest = "1234567890";
 numberAddressTest = "1234 Santa Dr";
 tooBigContactId = "12345678900987654321";
 tooBigFirstName = "michael michael";
 tooBigLastName = "michealstendast";
 tooBigPhoneNumber = "12345678900";
 tooSmallPhoneNumber = "12345";
 tooBigNumberAddress = "1234 Santa Washington Dr, Fort-Worth, Texas-76086";
 }
 //doesnt return null value
 @Test
 void contactTest() {
 Contact contact = new Contact(contactIdTest, tooBigFirstName, lastNameTest,
numberAddressTest, phoneNumberTest);
 assertNotNull(contact);
 }

 //all tests below are the same
 //ensures that it throws exceptions when given a null value or too big/small of a value
 //ensures that values equal expected when given proper input
 @Test
 void updateFirstNameTest() {
 Contact contact = new Contact(contactIdTest, tooBigFirstName, lastNameTest, numberAddressTest, phoneNumberTest);
 contact.setFirstName(firstNameTest);
 assertThrows(IllegalArgumentException.class,
 () -> contact.setFirstName(null));
 assertThrows(IllegalArgumentException.class,
 () -> contact.setFirstName(tooBigFirstName));
 assertEquals(firstNameTest, contact.getFirstName());
 }
 @Test
 void updateContactIDTest() {
	 Contact contact = new Contact(contactIdTest, tooBigFirstName, lastNameTest,
	numberAddressTest, phoneNumberTest);
	 contact.setContactID(contactIdTest);
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setContactID(null));
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setContactID(tooBigContactId));
	 }
	 @Test
	 void updateLastNameTest() {
	 Contact contact = new Contact(contactIdTest, tooBigFirstName, lastNameTest,
	numberAddressTest, phoneNumberTest);
	 contact.setLastName(lastNameTest);
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setLastName(null));
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setFirstName(tooBigLastName));
	 assertEquals(lastNameTest, contact.getLastName());
	 }
	 @Test
	 void updateNumberAddressTest() {
	 Contact contact = new Contact(contactIdTest, tooBigFirstName, lastNameTest,
	numberAddressTest, phoneNumberTest);
	 contact.setNumberAddress(numberAddressTest);
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setNumberAddress(null));
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setNumberAddress(tooBigNumberAddress));
	 assertEquals(numberAddressTest, contact.getNumberAddress());
	 }
	 @Test
	 void updatePhoneNumberTest() {
	 Contact contact = new Contact(contactIdTest, tooBigFirstName, lastNameTest,
	numberAddressTest, phoneNumberTest);
	 contact.setPhoneNumber(phoneNumberTest);
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setPhoneNumber(null));
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setPhoneNumber(tooBigPhoneNumber));
	 assertThrows(IllegalArgumentException.class,
	 () -> contact.setPhoneNumber(tooSmallPhoneNumber));
	 assertEquals(phoneNumberTest, contact.getPhoneNumber());
	 }

	}